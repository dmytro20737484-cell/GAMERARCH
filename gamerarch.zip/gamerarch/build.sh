#!/usr/bin/env bash
# Виконується всередині контейнера archlinux (privileged)
set -euo pipefail
cd /work
pacman -Syu --noconfirm archiso git sed

P=/tmp/profile
cp -r /usr/share/archiso/configs/releng "$P"

# 1) multilib (потрібен для Steam і 32-бітних Vulkan/Mesa)
for f in "$P/pacman.conf" /etc/pacman.conf; do
  grep -q '^\[multilib\]' "$f" || printf '\n[multilib]\nInclude = /etc/pacman.d/mirrorlist\n' >> "$f"
done
pacman -Sy --noconfirm

# 2) ядро: linux -> linux-zen
sed -i '/^linux$/d;/^linux-headers$/d' "$P/packages.x86_64"
sed -i 's/vmlinuz-linux/vmlinuz-linux-zen/g; s/initramfs-linux/initramfs-linux-zen/g' \
  "$P"/grub/*.cfg "$P"/syslinux/*.cfg "$P"/efiboot/loader/entries/*.conf
mv "$P/airootfs/etc/mkinitcpio.d/linux.preset" "$P/airootfs/etc/mkinitcpio.d/linux-zen.preset"
sed -i 's/vmlinuz-linux/vmlinuz-linux-zen/g; s/initramfs-linux/initramfs-linux-zen/g' \
  "$P/airootfs/etc/mkinitcpio.d/linux-zen.preset"

# 3) пакети
grep -vE '^\s*(#|$)' packages.txt >> "$P/packages.x86_64"

# 4) наші файли (конфіги, tweaks, скрипти)
cp -r overlay/* "$P/airootfs/"
mkdir -p "$P/airootfs/usr/share/gamershell"
cp -r overlay/etc "$P/airootfs/usr/share/gamershell/etc"
rm -rf "$P"/airootfs/usr/share/gamershell/etc/{sddm.conf.d,sysctl.d,sudoers.d}

# 5) користувач gamer без пароля + автологін
echo 'gamer:x:1000:1000:Gamer:/home/gamer:/bin/zsh' >> "$P/airootfs/etc/passwd"
echo 'gamer::14871::::::' >> "$P/airootfs/etc/shadow"
echo 'gamer:x:1000:' >> "$P/airootfs/etc/group"
echo 'gamer:!::' >> "$P/airootfs/etc/gshadow"
mkdir -p "$P/airootfs/home/gamer"
cat >> "$P/profiledef.sh" <<'EOP'
file_permissions+=(
  ["/home/gamer"]="1000:1000:750"
  ["/usr/local/bin/gamer-setup"]="0:0:755"
  ["/usr/local/bin/protonrun"]="0:0:755"
  ["/usr/local/bin/gamemode-toggle"]="0:0:755"
  ["/usr/local/bin/gamershell-install"]="0:0:755"
  ["/etc/sudoers.d/gamer"]="0:0:440"
)
EOP

# 6) сервіси
mkdir -p "$P/airootfs/etc/systemd/system/multi-user.target.wants"
ln -sf /usr/lib/systemd/system/NetworkManager.service \
  "$P/airootfs/etc/systemd/system/multi-user.target.wants/NetworkManager.service"
ln -sf /usr/lib/systemd/system/thermald.service \
  "$P/airootfs/etc/systemd/system/multi-user.target.wants/thermald.service"
ln -sf /usr/lib/systemd/system/power-profiles-daemon.service \
  "$P/airootfs/etc/systemd/system/multi-user.target.wants/power-profiles-daemon.service"
ln -sf /usr/lib/systemd/system/sddm.service \
  "$P/airootfs/etc/systemd/system/display-manager.service"

# 7) збірка
sed -i 's/^iso_name=.*/iso_name="gamerarch"/' "$P/profiledef.sh"
mkarchiso -v -w /tmp/work -o /work/out "$P"
