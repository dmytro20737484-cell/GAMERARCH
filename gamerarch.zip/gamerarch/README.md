# GamerArch — ігровий Arch Linux ISO

Що всередині: ядро linux-zen, KDE Plasma, Steam, Lutris, Wine-staging,
Gamescope, GameMode, MangoHud, Vulkan для AMD/Intel/NVIDIA (NVK), PipeWire,
sysctl-тюнінг для ігор, автологін користувача `gamer`.

## Як зібрати з телефона (GitHub Actions)
1. Створи репозиторій на GitHub, завантаж ці файли (зберігаючи структуру).
2. Вкладка Actions -> "Build GamerArch ISO" -> Run workflow.
3. Через ~20-40 хв завантаж ISO з Artifacts.
4. Запиши на флешку (Ventoy / Rufus / balenaEtcher на ПК), завантажся.

## Встановлення на диск
У live-системі відкрий Konsole: `archinstall`, потім після перезавантаження `sudo gamer-setup`.

## Ноутбук (i5-10210U + MX330)
MX330 — Pascal, тому в live-ISO працює Intel UHD (драйвер NVIDIA встановлюється через `gamer-setup`,
використовується legacy-пакет nvidia-580xx з AUR). Ігри запускай з `prime-run`.
Очікування: MX330 — слабка карта, ставити низькі/середні налаштування, 720p–1080p, FSR через gamescope.

## GamerShell (кастомна оболонка)
Sway + Waybar + Wofi + Mako, темна тема з неоновими акцентами, розкладки US/UA (Alt+Shift).
Гарячі клавіші (Super = клавіша Windows):
- Super+Enter термінал, Super+D меню програм, Super+Q закрити вікно, Super+F повний екран
- Super+G — ProtonRun, Super+S — Steam, Super+W — Firefox, Super+M — музичний плеєр (Strawberry)
- Super+Shift+G — ігровий режим (без рамок/відступів, без сповіщень, performance)
- Super+Shift+S скріншот області, Print — скріншот екрана, Super+L — блокування
- Super+1..5 робочі столи, Super+Shift+E вихід
KDE Plasma лишається в системі: у SDDM можна вибрати сеанс "Plasma".
Для встановленої системи: `sudo gamershell-install /mnt` одразу після archinstall.

## Екран завантаження (Plymouth)
Тема `gamerarch`: неоновий логотип, що пульсує, кільце, що обертається, смуга прогресу з написом SYSTEM BOOT.
Вмикається автоматично через `sudo gamershell-install /mnt` (додає хук plymouth, параметри `quiet splash`
для GRUB/systemd-boot і перегенеровує initramfs). У самому live-ISO екрана завантаження нема — тільки в встановленій системі.
Не збережеться, якщо завантажувач нестандартний: тоді додай `quiet splash` до параметрів ядра вручну.
